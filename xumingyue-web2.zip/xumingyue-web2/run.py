from app import app, db  # noqa: E402, F401


if __name__ == "__main__":
    app.run(debug=True)
